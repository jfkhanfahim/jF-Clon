package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.clon.CloneManager
import com.lody.virtual.client.core.VirtualCore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JF Clon", appName)
    }

    @Test
    fun `verify virtual core startup and launch intent`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val virtualCore = VirtualCore.get()
        virtualCore.startup(context)
        assertTrue(virtualCore.isEngineRunning())

        // Test launch intent generation for virtual space
        val intent = virtualCore.getLaunchIntent(context.packageName, 1)
        assertNotNull(intent)
        assertTrue(intent?.getBooleanExtra("com.lody.virtual.VIRTUAL_SPACE", false) == true)
        assertEquals(1, intent?.getIntExtra("com.lody.virtual.EXTRA_USER_ID", 0))
    }

    @Test
    fun `verify clone manager initialization`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = CloneManager.getInstance(context)
        manager.init()
        assertNotNull(manager.clonedAppsFlow.value)
    }
}
