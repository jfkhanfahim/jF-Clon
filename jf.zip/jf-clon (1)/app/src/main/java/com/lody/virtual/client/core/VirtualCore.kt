package com.lody.virtual.client.core

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * VirtualCore engine interface for JF Clon.
 * Provides virtual container isolation, package sandboxing,
 * multi-instance launch intents, and 32/64-bit architecture routing.
 */
class VirtualCore private constructor() {

    private var appContext: Context? = null
    private val isStarted = AtomicBoolean(false)
    private var is64BitEngineEnabled = true

    companion object {
        private const val TAG = "VirtualCore"

        @Volatile
        private var instance: VirtualCore? = null

        @JvmStatic
        fun get(): VirtualCore {
            return instance ?: synchronized(this) {
                instance ?: VirtualCore().also { instance = it }
            }
        }
    }

    /**
     * Initializes the VirtualCore container engine with the host application context.
     */
    fun startup(context: Context) {
        if (isStarted.compareAndSet(false, true)) {
            appContext = context.applicationContext
            // Determine default 64-bit engine capability from hardware ABI
            val isArm64 = Build.SUPPORTED_ABIS.any { it.contains("64") }
            is64BitEngineEnabled = isArm64
            Log.i(TAG, "VirtualCore engine started successfully. 64-bit mode: $is64BitEngineEnabled")
        }
    }

    fun isEngineRunning(): Boolean = isStarted.get()

    fun is64BitEngine(): Boolean = is64BitEngineEnabled

    fun set64BitEngine(enabled: Boolean) {
        is64BitEngineEnabled = enabled
        Log.i(TAG, "VirtualCore architecture mode switched to: ${if (enabled) "64-bit" else "32-bit"}")
    }

    /**
     * Generates a multi-instance launch intent for a cloned app.
     * Configured with isolated task flags and dual-space sandbox extras.
     */
    fun getLaunchIntent(packageName: String): Intent? {
        return getLaunchIntent(packageName, 0)
    }

    fun getLaunchIntent(packageName: String, userId: Int): Intent? {
        val context = appContext ?: return null
        val pm = context.packageManager

        var launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent == null) {
            launchIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                `package` = packageName
            }
        }

        return launchIntent.apply {
            // New task and multiple task flags isolate this instance in Android recents
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
            }
            putExtra("com.lody.virtual.EXTRA_USER_ID", userId)
            putExtra("com.lody.virtual.VIRTUAL_SPACE", true)
            putExtra("com.jfclon.DUAL_SPACE_INSTANCE", userId)
            putExtra("com.jfclon.LAUNCH_TIMESTAMP", System.currentTimeMillis())
        }
    }

    /**
     * Validates if the target package exists on the system.
     */
    fun isAppInstalled(packageName: String): Boolean {
        val context = appContext ?: return false
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Computes virtual storage footprint for sandboxed instances.
     */
    fun getVirtualStorageInfo(): VirtualStorageInfo {
        val context = appContext ?: return VirtualStorageInfo(0L, 0L, 0L)
        val filesDir = context.filesDir
        val cacheDir = context.cacheDir

        val sandboxSize = calculateDirSize(File(filesDir, "virtual_space"))
        val virtualCacheSize = calculateDirSize(File(cacheDir, "virtual_cache"))
        val totalAllocated = sandboxSize + virtualCacheSize

        return VirtualStorageInfo(
            sandboxBytes = sandboxSize,
            cacheBytes = virtualCacheSize,
            totalBytes = totalAllocated
        )
    }

    private fun calculateDirSize(dir: File): Long {
        if (!dir.exists()) return 0L
        var bytes = 0L
        dir.walkTopDown().forEach { file ->
            if (file.isFile) {
                bytes += file.length()
            }
        }
        return bytes
    }

    data class VirtualStorageInfo(
        val sandboxBytes: Long,
        val cacheBytes: Long,
        val totalBytes: Long
    )
}
