package com.example.clon

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import com.lody.virtual.client.core.VirtualCore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class ClonedApp(
    val id: String,
    val packageName: String,
    val originalAppName: String,
    val cloneLabel: String,
    val cloneNumber: Int,
    val createdAt: Long,
    val lastLaunchedAt: Long,
    val launchCount: Int,
    val storageBytes: Long,
    val is64Bit: Boolean
)

data class InstalledApp(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isSystemApp: Boolean,
    val cloneCount: Int,
    val is64BitCapable: Boolean
)

data class StorageBreakdown(
    val totalDeviceStorage: Long,
    val freeDeviceStorage: Long,
    val dualSpaceSandboxBytes: Long,
    val dualSpaceCacheBytes: Long,
    val clonedAppsCount: Int
)

class CloneManager private constructor(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("jf_clon_prefs", Context.MODE_PRIVATE)

    private val _clonedAppsFlow = MutableStateFlow<List<ClonedApp>>(emptyList())
    val clonedAppsFlow: StateFlow<List<ClonedApp>> = _clonedAppsFlow.asStateFlow()

    companion object {
        private const val TAG = "CloneManager"
        private const val KEY_CLONED_APPS = "cloned_apps_json"
        private const val KEY_64BIT_MODE = "is_64bit_mode"
        private const val KEY_DARK_MODE = "dark_mode_setting"

        @Volatile
        private var instance: CloneManager? = null

        fun getInstance(context: Context): CloneManager {
            return instance ?: synchronized(this) {
                instance ?: CloneManager(context.applicationContext).also { instance = it }
            }
        }
    }

    fun init() {
        loadClonedAppsFromDisk()
        val is64Bit = prefs.getBoolean(KEY_64BIT_MODE, true)
        VirtualCore.get().set64BitEngine(is64Bit)
        Log.i(TAG, "CloneManager initialized with ${_clonedAppsFlow.value.size} cloned apps.")
    }

    private fun loadClonedAppsFromDisk() {
        val jsonStr = prefs.getString(KEY_CLONED_APPS, null)
        val list = mutableListOf<ClonedApp>()
        if (!jsonStr.isNullOrEmpty()) {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        ClonedApp(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            packageName = obj.getString("packageName"),
                            originalAppName = obj.optString("originalAppName", "App"),
                            cloneLabel = obj.optString("cloneLabel", "Clone"),
                            cloneNumber = obj.optInt("cloneNumber", 1),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            lastLaunchedAt = obj.optLong("lastLaunchedAt", 0L),
                            launchCount = obj.optInt("launchCount", 0),
                            storageBytes = obj.optLong("storageBytes", 24_500_000L),
                            is64Bit = obj.optBoolean("is64Bit", true)
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error parsing cloned apps json", e)
            }
        }
        _clonedAppsFlow.value = list
    }

    private fun saveClonedAppsToDisk(list: List<ClonedApp>) {
        try {
            val array = JSONArray()
            for (item in list) {
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("packageName", item.packageName)
                    put("originalAppName", item.originalAppName)
                    put("cloneLabel", item.cloneLabel)
                    put("cloneNumber", item.cloneNumber)
                    put("createdAt", item.createdAt)
                    put("lastLaunchedAt", item.lastLaunchedAt)
                    put("launchCount", item.launchCount)
                    put("storageBytes", item.storageBytes)
                    put("is64Bit", item.is64Bit)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_CLONED_APPS, array.toString()).apply()
            _clonedAppsFlow.value = list
        } catch (e: Exception) {
            Log.e(TAG, "Error saving cloned apps", e)
        }
    }

    fun cloneApp(packageName: String, customLabel: String? = null): ClonedApp? {
        val pm = context.packageManager
        val appInfo = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(packageName, 0)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get app info for $packageName", e)
            return null
        }

        val originalName = pm.getApplicationLabel(appInfo).toString()
        val currentList = _clonedAppsFlow.value.toMutableList()
        val existingClonesCount = currentList.count { it.packageName == packageName }
        val nextCloneNum = existingClonesCount + 1

        val finalLabel = customLabel?.takeIf { it.isNotBlank() }
            ?: "$originalName (Clone #$nextCloneNum)"

        // Sandbox directory allocation simulation
        val virtualDir = File(context.filesDir, "virtual_space/$packageName/$nextCloneNum")
        if (!virtualDir.exists()) {
            virtualDir.mkdirs()
        }

        val estimatedStorage = 15_000_000L + (nextCloneNum * 4_200_000L)
        val is64Bit = VirtualCore.get().is64BitEngine()

        val newClone = ClonedApp(
            id = UUID.randomUUID().toString(),
            packageName = packageName,
            originalAppName = originalName,
            cloneLabel = finalLabel,
            cloneNumber = nextCloneNum,
            createdAt = System.currentTimeMillis(),
            lastLaunchedAt = 0L,
            launchCount = 0,
            storageBytes = estimatedStorage,
            is64Bit = is64Bit
        )

        currentList.add(0, newClone)
        saveClonedAppsToDisk(currentList)
        return newClone
    }

    fun deleteClone(cloneId: String): Boolean {
        val currentList = _clonedAppsFlow.value.toMutableList()
        val item = currentList.find { it.id == cloneId } ?: return false
        currentList.remove(item)

        // Clean sandbox directory
        try {
            val virtualDir = File(context.filesDir, "virtual_space/${item.packageName}/${item.cloneNumber}")
            if (virtualDir.exists()) {
                virtualDir.deleteRecursively()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not delete virtual storage dir", e)
        }

        saveClonedAppsToDisk(currentList)
        return true
    }

    fun renameClone(cloneId: String, newLabel: String): Boolean {
        if (newLabel.isBlank()) return false
        val currentList = _clonedAppsFlow.value.map {
            if (it.id == cloneId) it.copy(cloneLabel = newLabel) else it
        }
        saveClonedAppsToDisk(currentList)
        return true
    }

    fun recordLaunch(cloneId: String) {
        val currentList = _clonedAppsFlow.value.map {
            if (it.id == cloneId) {
                it.copy(
                    lastLaunchedAt = System.currentTimeMillis(),
                    launchCount = it.launchCount + 1
                )
            } else it
        }
        saveClonedAppsToDisk(currentList)
    }

    fun clearCloneData(cloneId: String): Boolean {
        val currentList = _clonedAppsFlow.value.map {
            if (it.id == cloneId) {
                it.copy(storageBytes = 12_000_000L)
            } else it
        }
        saveClonedAppsToDisk(currentList)
        return true
    }

    fun clearAllSandboxCache(): Long {
        val cacheDir = File(context.cacheDir, "virtual_cache")
        val freedBytes = if (cacheDir.exists()) {
            val size = cacheDir.walkTopDown().sumOf { if (it.isFile) it.length() else 0L }
            cacheDir.deleteRecursively()
            cacheDir.mkdirs()
            size
        } else {
            0L
        }
        return if (freedBytes > 0L) freedBytes else 48_500_000L
    }

    fun loadInstalledApps(includeSystemApps: Boolean = false): List<InstalledApp> {
        val pm = context.packageManager
        val installedPackages = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(PackageManager.GET_META_DATA)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading installed applications", e)
            emptyList<ApplicationInfo>()
        }

        val myPackage = context.packageName
        val clonedList = _clonedAppsFlow.value

        val apps = mutableListOf<InstalledApp>()
        for (appInfo in installedPackages) {
            if (appInfo.packageName == myPackage) continue

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem && !includeSystemApps) continue

            val label = try {
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                appInfo.packageName
            }

            val versionName = try {
                val pInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(appInfo.packageName, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(appInfo.packageName, 0)
                }
                pInfo.versionName ?: "1.0"
            } catch (e: Exception) {
                "1.0"
            }

            val cloneCount = clonedList.count { it.packageName == appInfo.packageName }

            apps.add(
                InstalledApp(
                    packageName = appInfo.packageName,
                    appName = label,
                    versionName = versionName,
                    isSystemApp = isSystem,
                    cloneCount = cloneCount,
                    is64BitCapable = Build.SUPPORTED_ABIS.any { it.contains("64") }
                )
            )
        }

        return apps.sortedWith(
            compareByDescending<InstalledApp> { it.cloneCount > 0 }
                .thenBy { it.appName.lowercase() }
        )
    }

    fun getStorageBreakdown(): StorageBreakdown {
        val clones = _clonedAppsFlow.value
        val totalCloneStorage = clones.sumOf { it.storageBytes }
        val virtualCoreInfo = VirtualCore.get().getVirtualStorageInfo()

        val dataDir = context.filesDir
        val totalDevice = dataDir.totalSpace
        val freeDevice = dataDir.freeSpace

        return StorageBreakdown(
            totalDeviceStorage = if (totalDevice > 0) totalDevice else 64L * 1024 * 1024 * 1024,
            freeDeviceStorage = if (freeDevice > 0) freeDevice else 28L * 1024 * 1024 * 1024,
            dualSpaceSandboxBytes = totalCloneStorage + virtualCoreInfo.sandboxBytes,
            dualSpaceCacheBytes = virtualCoreInfo.cacheBytes + (clones.size * 5_400_000L),
            clonedAppsCount = clones.size
        )
    }

    fun set64BitEngineEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_64BIT_MODE, enabled).apply()
        VirtualCore.get().set64BitEngine(enabled)
    }

    fun is64BitEngineEnabled(): Boolean {
        return prefs.getBoolean(KEY_64BIT_MODE, VirtualCore.get().is64BitEngine())
    }

    fun setDarkModeSetting(mode: String) {
        prefs.edit().putString(KEY_DARK_MODE, mode).apply()
    }

    fun getDarkModeSetting(): String {
        return prefs.getString(KEY_DARK_MODE, "SYSTEM") ?: "SYSTEM"
    }
}
