package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dual Space Blue to Purple Palette
val DualBluePrimary = Color(0xFF2563EB)
val DualPurpleSecondary = Color(0xFF7C3AED)
val DualCyanAccent = Color(0xFF06B6D4)
val DualIndigoGlow = Color(0xFF4F46E5)

// Dark Theme Colors
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131C2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkOnSurface = Color(0xFFE2E8F0)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkPrimaryContainer = Color(0xFF1E3A8A)
val DarkOnPrimaryContainer = Color(0xFFDBEAFE)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF64748B)
val LightPrimaryContainer = Color(0xFFDBEAFE)
val LightOnPrimaryContainer = Color(0xFF1E40AF)
