package com.example

import android.app.Application
import android.util.Log
import com.example.clon.CloneManager
import com.lody.virtual.client.core.VirtualCore

/**
 * Main Application class for JF Clon.
 * Initializes VirtualCore engine and Dual Space sandbox repository.
 */
class JFApp : Application() {

    override fun onCreate() {
        super.onCreate()
        Log.i("JFApp", "Starting JF Clon application context...")
        
        // Initialize VirtualCore engine
        VirtualCore.get().startup(this)

        // Initialize CloneManager repository
        CloneManager.getInstance(this).init()

        Log.i("JFApp", "JF Clon core subsystems initialized successfully.")
    }
}
