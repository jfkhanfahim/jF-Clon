package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.clon.CloneManager
import com.example.clon.ClonedApp
import com.example.clon.InstalledApp
import com.example.clon.StorageBreakdown
import com.lody.virtual.client.core.VirtualCore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
    val isSplashScreen: Boolean = true,
    val selectedTab: Int = 0, // 0: Cloned Apps, 1: Installed Apps, 2: Settings
    val installedApps: List<InstalledApp> = emptyList(),
    val filteredApps: List<InstalledApp> = emptyList(),
    val clonedApps: List<ClonedApp> = emptyList(),
    val searchQuery: String = "",
    val selectedCategory: String = "All",
    val isCloning: Boolean = false,
    val cloningAppName: String = "",
    val cloningProgress: Float = 0f,
    val cloningStep: String = "",
    val selectedAppForClone: InstalledApp? = null,
    val storageBreakdown: StorageBreakdown? = null,
    val is64BitEngine: Boolean = true,
    val themeMode: String = "DARK", // DARK, LIGHT, SYSTEM
    val userMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val cloneManager = CloneManager.getInstance(application)
    private val virtualCore = VirtualCore.get()

    private val _uiState = MutableStateFlow(
        MainUiState(
            themeMode = cloneManager.getDarkModeSetting(),
            is64BitEngine = cloneManager.is64BitEngineEnabled()
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        // Collect cloned apps from CloneManager
        viewModelScope.launch {
            cloneManager.clonedAppsFlow.collectLatest { list ->
                _uiState.value = _uiState.value.copy(
                    clonedApps = list,
                    storageBreakdown = cloneManager.getStorageBreakdown()
                )
                // Also update clone counts on installed apps
                refreshInstalledApps()
            }
        }

        // Initialize apps list & splash screen delay
        viewModelScope.launch {
            loadInstalledApps()
            _uiState.value = _uiState.value.copy(
                storageBreakdown = cloneManager.getStorageBreakdown()
            )
            delay(1600)
            _uiState.value = _uiState.value.copy(isSplashScreen = false)
        }
    }

    fun selectTab(index: Int) {
        _uiState.value = _uiState.value.copy(selectedTab = index)
        if (index == 2) {
            refreshStorage()
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        applyFilters()
    }

    fun onCategorySelected(category: String) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
        applyFilters()
    }

    private fun applyFilters() {
        val all = _uiState.value.installedApps
        val query = _uiState.value.searchQuery.trim().lowercase()
        val cat = _uiState.value.selectedCategory

        val filtered = all.filter { app ->
            val matchesQuery = query.isEmpty() ||
                    app.appName.lowercase().contains(query) ||
                    app.packageName.lowercase().contains(query)

            val matchesCat = when (cat) {
                "All" -> true
                "Social" -> isSocialApp(app.packageName)
                "Games" -> isGameApp(app.packageName)
                "Tools" -> isToolApp(app.packageName)
                else -> true
            }

            matchesQuery && matchesCat
        }

        _uiState.value = _uiState.value.copy(filteredApps = filtered)
    }

    private fun isSocialApp(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.contains("whatsapp") || lower.contains("facebook") ||
                lower.contains("instagram") || lower.contains("twitter") ||
                lower.contains("telegram") || lower.contains("messenger") ||
                lower.contains("snapchat") || lower.contains("discord") ||
                lower.contains("tiktok") || lower.contains("linkedin") ||
                lower.contains("viber") || lower.contains("wechat") ||
                lower.contains("reddit")
    }

    private fun isGameApp(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.contains("game") || lower.contains("unity") ||
                lower.contains("pubg") || lower.contains("freefire") ||
                lower.contains("roblox") || lower.contains("clash") ||
                lower.contains("candycrush") || lower.contains("minecraft") ||
                lower.contains("supercell") || lower.contains("mihoyo")
    }

    private fun isToolApp(pkg: String): Boolean {
        val lower = pkg.lowercase()
        return lower.contains("browser") || lower.contains("chrome") ||
                lower.contains("drive") || lower.contains("calculator") ||
                lower.contains("notes") || lower.contains("clock") ||
                lower.contains("camera") || lower.contains("gallery") ||
                lower.contains("office") || lower.contains("mail")
    }

    fun showCloneDialog(app: InstalledApp) {
        _uiState.value = _uiState.value.copy(selectedAppForClone = app)
    }

    fun dismissCloneDialog() {
        _uiState.value = _uiState.value.copy(selectedAppForClone = null)
    }

    fun confirmClone(app: InstalledApp, customLabel: String?) {
        _uiState.value = _uiState.value.copy(
            selectedAppForClone = null,
            isCloning = true,
            cloningAppName = app.appName,
            cloningProgress = 0.1f,
            cloningStep = "Initializing Virtual Core Sandbox…"
        )

        viewModelScope.launch {
            delay(350)
            _uiState.value = _uiState.value.copy(
                cloningProgress = 0.4f,
                cloningStep = "Allocating Dual Space Storage Container…"
            )
            delay(400)
            _uiState.value = _uiState.value.copy(
                cloningProgress = 0.75f,
                cloningStep = "Configuring isolated process sandbox…"
            )
            delay(350)

            withContext(Dispatchers.IO) {
                cloneManager.cloneApp(app.packageName, customLabel)
            }

            _uiState.value = _uiState.value.copy(
                cloningProgress = 1.0f,
                cloningStep = "Clone created successfully!",
                isCloning = false,
                selectedTab = 0, // Switch to Cloned Apps tab
                userMessage = "Successfully cloned ${app.appName} to Space 2"
            )
        }
    }

    fun launchClonedApp(context: Context, clone: ClonedApp) {
        viewModelScope.launch {
            cloneManager.recordLaunch(clone.id)
            try {
                // Call VirtualCore getLaunchIntent as requested
                val launchIntent = virtualCore.getLaunchIntent(clone.packageName, clone.cloneNumber)
                if (launchIntent != null) {
                    context.startActivity(launchIntent)
                    _uiState.value = _uiState.value.copy(
                        userMessage = "Launching ${clone.cloneLabel} in Dual Space sandbox…"
                    )
                } else {
                    _uiState.value = _uiState.value.copy(
                        userMessage = "Could not find launchable intent for ${clone.originalAppName}"
                    )
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Error launching cloned app", e)
                _uiState.value = _uiState.value.copy(
                    userMessage = "Launch error: ${e.localizedMessage ?: "Unknown error"}"
                )
            }
        }
    }

    fun deleteClone(clone: ClonedApp) {
        viewModelScope.launch(Dispatchers.IO) {
            cloneManager.deleteClone(clone.id)
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    userMessage = "Deleted ${clone.cloneLabel}"
                )
            }
        }
    }

    fun renameClone(clone: ClonedApp, newLabel: String) {
        viewModelScope.launch(Dispatchers.IO) {
            cloneManager.renameClone(clone.id, newLabel)
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    userMessage = "Renamed to $newLabel"
                )
            }
        }
    }

    fun clearCloneStorage(clone: ClonedApp) {
        viewModelScope.launch(Dispatchers.IO) {
            cloneManager.clearCloneData(clone.id)
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    userMessage = "Cleared virtual sandbox data for ${clone.cloneLabel}"
                )
            }
        }
    }

    fun clearAllCache() {
        viewModelScope.launch(Dispatchers.IO) {
            val freed = cloneManager.clearAllSandboxCache()
            val mb = freed / (1024 * 1024)
            val updated = cloneManager.getStorageBreakdown()
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    storageBreakdown = updated,
                    userMessage = "Cleared ${mb}MB of temporary sandbox cache"
                )
            }
        }
    }

    fun toggle64BitEngine(enabled: Boolean) {
        cloneManager.set64BitEngineEnabled(enabled)
        _uiState.value = _uiState.value.copy(
            is64BitEngine = enabled,
            userMessage = if (enabled) "Switched to 64-bit VirtualCore engine" else "Switched to 32-bit compatibility engine"
        )
    }

    fun setThemeMode(mode: String) {
        cloneManager.setDarkModeSetting(mode)
        _uiState.value = _uiState.value.copy(themeMode = mode)
    }

    fun dismissMessage() {
        _uiState.value = _uiState.value.copy(userMessage = null)
    }

    fun refreshInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = cloneManager.loadInstalledApps(includeSystemApps = false)
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(installedApps = apps)
                applyFilters()
            }
        }
    }

    private suspend fun loadInstalledApps() {
        withContext(Dispatchers.IO) {
            val apps = cloneManager.loadInstalledApps(includeSystemApps = false)
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(installedApps = apps)
                applyFilters()
            }
        }
    }

    private fun refreshStorage() {
        viewModelScope.launch(Dispatchers.IO) {
            val stats = cloneManager.getStorageBreakdown()
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(storageBreakdown = stats)
            }
        }
    }
}
